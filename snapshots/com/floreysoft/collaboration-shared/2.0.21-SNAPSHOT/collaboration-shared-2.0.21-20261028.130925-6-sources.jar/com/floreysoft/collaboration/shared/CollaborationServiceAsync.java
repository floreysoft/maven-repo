package com.floreysoft.collaboration.shared;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.floreysoft.appcore.shared.AppCoreServiceAsync;
import com.floreysoft.collaboration.shared.command.Command;
import com.floreysoft.collaboration.shared.command.CommandsResult;
import com.floreysoft.collaboration.shared.picker.Folder;
import com.floreysoft.collaboration.shared.picker.Query;
import com.floreysoft.collaboration.shared.picker.QueryCapabilities;
import com.floreysoft.collaboration.shared.picker.Row;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface CollaborationServiceAsync extends AppCoreServiceAsync {
	void runCommands(String locale, String email, String uiChannel, String fileId, List<Command> commands, AsyncCallback<CommandsResult> callback);

	void getRevisions(String locale, String actor, String id, AsyncCallback<List<DriveFileRevision>> callback);

	void getRevision(String locale, String email, String fileId, String revisionId, AsyncCallback<DriveFileRevision> callback);
	
	void getChatMessages(String locale, String email, String fileId, Date chatTimestamp, AsyncCallback<List<ChatMessage>> callback);

	void sendChatMessage(String locale, String email, String fileId, ChatMessage chatMessage, AsyncCallback<Void> callback);

	void rename(String locale, String actor, String fileId, String name, String description, AsyncCallback<Void> callback);

	void save(String locale, String actor, String fileId, String mimeType, boolean force, AsyncCallback<Void> callback);

	void getExample(String locale, String key, AsyncCallback<Example> callback);

	void getExamples(String locale, AsyncCallback<List<Example>> callback);

	void moveToFolder(String locale, String email, String fileId, String selectedFolderId, AsyncCallback<Void> callback);

	void searchFiles(String locale, String email, String query, String cursor, String orderBy, int pageSize, AsyncCallback<QueryResult<DriveFile>> callback);

	void getQueryCapabilities(String locale, String actor, String uiChannel, Map<String, Object> context,
			AsyncCallback<QueryCapabilities> callback);

	void executeQuery(String locale, String actor, String uiChannel, Query query, Map<String, Object> context,
			AsyncCallback<QueryResult<Row>> callback);

	void getFolders(String locale, String actor, String uiChannel, Query query, String path, Map<String, Object> context,
			AsyncCallback<QueryResult<Folder>> callback);

	void trashFile(String locale, String email, String fileId, boolean trash, AsyncCallback<Void> callback);
}