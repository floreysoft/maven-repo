package com.floreysoft.collaboration.shared;

import java.io.Serializable;
import java.util.Date;

public class DriveFile implements Serializable {
	private String fileId, lastModifyingUser, contentType, name, path, description, thumbnailLink;
	private Date lastModified;

	public DriveFile() {
	}

	public DriveFile(String fileId, String lastModifyingUser, String contentType, String name, String description, String thumbnailLink, Date lastModified) {
		this.fileId = fileId;
		this.lastModifyingUser = lastModifyingUser;
		this.contentType = contentType;
		this.name = name;
		this.description = description;
		this.thumbnailLink = thumbnailLink;
		this.lastModified = lastModified;
	}

	public DriveFile(String fileId, String contentType, String name, String description, String thumbnailLink) {
		this.fileId = fileId;
		this.contentType = contentType;
		this.name = name;
		this.description = description;
		this.thumbnailLink = thumbnailLink;
	}

	public DriveFile(String fileId, String contentType, String name, String path) {
		this.fileId = fileId;
		this.contentType = contentType;
		this.name = name;
		this.path = path;
	}

	public void setContentType(String contentType) {
		this.contentType = contentType;
	}

	public String getContentType() {
		return contentType;
	}

	public String getFileId() {
		return fileId;
	}

	public void setFileId(String fileId) {
		this.fileId = fileId;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getThumbnailLink() {
		return thumbnailLink;
	}

	public void setThumbnailLink(String thumbnailLink) {
		this.thumbnailLink = thumbnailLink;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String parent) {
		this.path = parent;
	}

	public String getLastModifyingUser() {
		return lastModifyingUser;
	}

	public void setLastModifyingUser(String lastModifyingUser) {
		this.lastModifyingUser = lastModifyingUser;
	}

	public Date getLastModified() {
		return lastModified;
	}

	public void setLastModified(Date lastModified) {
		this.lastModified = lastModified;
	}

	@Override
	public boolean equals(Object obj) {
		return obj instanceof DriveFile && ((DriveFile) obj).getFileId().equals(fileId);
	}
}