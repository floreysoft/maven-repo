package com.floreysoft.collaboration.shared.command;

public class UndoCommand extends Command {
	private String undoKey;

	public UndoCommand() {
	}
	
	public UndoCommand(String undoKey) {
		this.undoKey = undoKey;
	}
	
	public String getUndoKey() {
		return undoKey;
	}

	@Override
	public int getMaxDelay() {
		return 0;
	}

	@Override
	public boolean isUndoSupported() {
		return false;
	}
}

