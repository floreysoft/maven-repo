package com.floreysoft.collaboration.shared;

public interface RevisionFailureHandler {
	void checkRevision(Throwable caught);
}
