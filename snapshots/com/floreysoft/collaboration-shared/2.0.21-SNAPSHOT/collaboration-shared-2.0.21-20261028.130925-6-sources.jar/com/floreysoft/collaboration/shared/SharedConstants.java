package com.floreysoft.collaboration.shared;

import com.floreysoft.appcore.shared.Scope;

public interface SharedConstants extends com.floreysoft.appcore.shared.SharedConstants {
	public static final Scope DRIVE_SCOPE = new Scope("https://www.googleapis.com/auth/drive");
	public static final Scope DRIVE_FILE_SCOPE = new Scope(DRIVE_SCOPE, "https://www.googleapis.com/auth/drive.file");
	public static final Scope DRIVE_READONLY_SCOPE = new Scope(DRIVE_SCOPE, "https://www.googleapis.com/auth/drive.readonly");
	public static final Scope DRIVE_METADATA_SCOPE = new Scope(DRIVE_SCOPE, "https://www.googleapis.com/auth/drive.metadata");
	public static final Scope DRIVE_METADATA_READONLY_SCOPE = new Scope(DRIVE_READONLY_SCOPE, "https://www.googleapis.com/auth/drive.metadata.readonly");

	public static final String DRIVE_ACTION_CREATE = "create";
	public static final String DRIVE_ACTION_OPEN = "open";
	public static final String DRIVE_ACTION = "driveAction";
	public static final String DRIVE_FILE_ID = "driveFileId";
	public static final String DRIVE_PARENT_ID = "driveParentId";
	public static final String EXAMPLE_ID = "exampleId";
	
	public static final String PARAMETER_ACTOR = "actor";
}
