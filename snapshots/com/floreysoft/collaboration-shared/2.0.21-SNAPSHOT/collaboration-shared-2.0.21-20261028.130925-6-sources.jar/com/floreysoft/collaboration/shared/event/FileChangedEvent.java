package com.floreysoft.collaboration.shared.event;

import java.util.Date;

import com.floreysoft.appcore.shared.event.TaskEvent;

public class FileChangedEvent extends TaskEvent {
	private Date timestamp;

	public FileChangedEvent() {
	}
	
	public FileChangedEvent(Date timestamp) {
		this.timestamp = timestamp;
	}

	public Date getTimestamp() {
		return timestamp;
	}
}