package com.floreysoft.collaboration.shared.picker;

import java.io.Serializable;

public class Folder implements Serializable {
	private static final long serialVersionUID = 1L;
	
	private String id, displayName, icon, color, path;
	boolean children;
	
	public Folder() {
	}

	public Folder(String id, String displayName, String icon, String color, boolean children) {
		this(id, displayName, icon, color, children, null);
	}
	
	public Folder(String id, String displayName, String icon, String color, boolean children, String path) {
		this.id = id;
		this.displayName = displayName;
		this.icon = icon;
		this.color = color;
		this.children = children;
		this.path = path;
	}

	public String getId() {
		return id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getIcon() {
		return icon;
	}

	public String getColor() {
		return color;
	}

	public boolean hasChildren() {
		return children;
	}

	public String getPath() {
		return path;
	}
}