package com.floreysoft.collaboration.shared;

public class RevisionInvalidException extends Exception {
	private long revision;
	private String content;

	public RevisionInvalidException() {
	}

	public long getRevision() {
		return revision;
	}

	public String getContent() {
		return content;
	}

	public RevisionInvalidException(String message, long revision, String content) {
		super(message);
		this.revision = revision;
		this.content = content;
	}

}
