package com.floreysoft.collaboration.shared.picker;

import java.util.List;

import com.google.gwt.user.client.rpc.IsSerializable;

public class QueryCapabilities implements IsSerializable {
	public static class SearchCapabilities implements IsSerializable {
		public SearchCapabilities() {
		}
	}
	
	// Provides search capabilities, column names etc.
	private List<ColumnDefinition> columnDefinitions;
	private List<Folder> folders;
	private Row defaultSelection;
	private int nodeSize, pageSize;
	private boolean multiselect;
	private SearchCapabilities searchCapabilities;
	
	public QueryCapabilities() {
	}

	public QueryCapabilities(List<ColumnDefinition> columnDefinitions, List<Folder> folders, Row defaultSelection, int nodeSize, int pageSize, boolean multiselect, SearchCapabilities searchCapabilities) {
		this.columnDefinitions = columnDefinitions;
		this.folders = folders;
		this.defaultSelection = defaultSelection;
		this.nodeSize = nodeSize;
		this.pageSize = pageSize;
		this.multiselect = multiselect;
		this.searchCapabilities = searchCapabilities;
	}

	public void setFolders(List<Folder> folders) {
		this.folders = folders;
	}

	public List<Folder> getFolders() {
		return folders;
	}

	public List<ColumnDefinition> getColumnDefinitions() {
		return columnDefinitions;
	}

	public Row getDefaultSelection() {
		return defaultSelection;
	}

	public int getNodeSize() {
		return nodeSize;
	}

	public int getPageSize() {
		return pageSize;
	}

	public boolean isMultiselect() {
		return multiselect;
	}

	public SearchCapabilities getSearchCapabilities() {
		return searchCapabilities;
	}
}