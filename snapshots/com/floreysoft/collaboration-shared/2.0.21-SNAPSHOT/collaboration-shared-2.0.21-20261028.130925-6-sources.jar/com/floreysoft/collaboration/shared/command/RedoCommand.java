package com.floreysoft.collaboration.shared.command;

public class RedoCommand extends Command {
	private String redoKey;

	public RedoCommand() {
	}
	
	public RedoCommand(String redoKey) {
		this.redoKey = redoKey;
	}
	
	public String getRedoKey() {
		return redoKey;
	}

	@Override
	public int getMaxDelay() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean isUndoSupported() {
		return false;
	}
}
