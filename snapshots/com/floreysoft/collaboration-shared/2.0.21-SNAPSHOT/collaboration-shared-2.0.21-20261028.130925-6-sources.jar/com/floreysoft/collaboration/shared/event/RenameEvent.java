package com.floreysoft.collaboration.shared.event;

public class RenameEvent extends CommandEvent {
	private String name, description;

	public RenameEvent() {
	}
	
	public RenameEvent(String uiChannel, String fileId, String name, String description) {
		super(uiChannel, fileId);
		this.name = name;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}
}