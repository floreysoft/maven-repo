package com.floreysoft.collaboration.shared;

import java.io.Serializable;

public class Example implements Serializable {
	private String owner, folderId, folderName, name, description, category, imageUrl, thumbnailUrl, backgroundUrl,
			previewUrl, videoId, helpUrl, pricingUrl, files;

	public Example() {
	}

	public Example(String owner, String folderId, String folderName, String name, String description, String category,
			String imageUrl, String thumbnailUrl, String backgroundUrl, String previewUrl, String videoId,
			String helpUrl, String pricingUrl, String files) {
		this.owner = owner;
		this.folderId = folderId;
		this.folderName = folderName;
		this.name = name;
		this.description = description;
		this.category = category;
		this.imageUrl = imageUrl;
		this.backgroundUrl = backgroundUrl;
		this.previewUrl = previewUrl;
		this.thumbnailUrl = thumbnailUrl;
		this.videoId = videoId;
		this.helpUrl = helpUrl;
		this.pricingUrl = pricingUrl;
		this.files = files;
	}

	public String getOwner() {
		return owner;
	}

	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}

	public String getFolderId() {
		return folderId;
	}

	public String getFolderName() {
		return folderName;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getImageUrl() {
		return imageUrl;
	}

	public String getBackgroundUrl() {
		return backgroundUrl;
	}

	public String getThumbnailUrl() {
		return thumbnailUrl;
	}

	public String getPreviewUrl() {
		return previewUrl;
	}

	public String getVideoId() {
		return videoId;
	}

	public String getHelpUrl() {
		return helpUrl;
	}

	public String getPricingUrl() {
		return pricingUrl;
	}

	public String getFiles() {
		return files;
	}
}
