package com.floreysoft.collaboration.shared.command;

import com.google.gwt.user.client.rpc.IsSerializable;

public class CommandsResult implements IsSerializable {
	private String undoKey, redoKey;
	private long nextSync;
	private long revision;

	public CommandsResult() {
	}

	public void setUndoKey(String undoKey) {
		this.undoKey = undoKey;
	}

	public void setRedoKey(String redoKey) {
		this.redoKey = redoKey;
	}

	public String getUndoKey() {
		return undoKey;
	}

	public String getRedoKey() {
		return redoKey;
	}

	public long getNextSync() {
		return nextSync;
	}

	public void setNextSync(long nextSync) {
		this.nextSync = nextSync;
	}

	public long getRevision() {
		return revision;
	}

	public void setRevision(long revision) {
		this.revision = revision;
	}
}