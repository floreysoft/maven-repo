package com.floreysoft.collaboration.shared.command;

import com.google.gwt.user.client.rpc.IsSerializable;

public abstract class Command implements IsSerializable {
	private String compound;

	public abstract int getMaxDelay();

	public abstract boolean isUndoSupported();

	public void setCompound(String compound) {
		this.compound = compound;
	}

	public String getCompound() {
		return compound;
	}

	public boolean isLightweight() {
		return false;
	}
}