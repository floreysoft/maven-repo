package com.floreysoft.collaboration.shared;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.floreysoft.appcore.shared.AppCoreService;
import com.floreysoft.collaboration.shared.command.Command;
import com.floreysoft.collaboration.shared.command.CommandsResult;
import com.floreysoft.collaboration.shared.picker.Folder;
import com.floreysoft.collaboration.shared.picker.Query;
import com.floreysoft.collaboration.shared.picker.QueryCapabilities;
import com.floreysoft.collaboration.shared.picker.Row;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * @author Daniel Florey
 * 
 */
@RemoteServiceRelativePath("collaborationService")
public interface CollaborationService extends AppCoreService {
	CommandsResult runCommands(String locale, String email, String uiChannel, String fileId, List<Command> commands) throws Exception;
	
	List<DriveFileRevision> getRevisions(String locale, String actor, String id) throws Exception;

	DriveFileRevision getRevision(String locale, String email, String fileId, String revisionId) throws Exception;

	void sendChatMessage(String locale, String email, String fileId, ChatMessage chatMessage) throws Exception;

	List<ChatMessage> getChatMessages(String locale, String email, String fileId, Date chatTimestamp) throws Exception;

	void rename(String locale, String actor, String fileId, String name, String description) throws Exception;

	void save(String locale, String actor, String fileId, String mimeType, boolean force) throws Exception;

	List<Example> getExamples(String locale) throws Exception;

	Example getExample(String locale, String key) throws Exception;
	
	void moveToFolder(String locale, String email, String fileId, String selectedFolderId) throws Exception;

	QueryResult<DriveFile> searchFiles(String locale, String email, String query, String orderBy, String cursor, int pageSize) throws Exception;

	QueryCapabilities getQueryCapabilities(String locale,  String actor, String uiChannel, Map<String, Object> context) throws Exception;

	QueryResult<Row> executeQuery(String locale, String actor, String uiChannel, Query query, Map<String, Object> context) throws Exception;
	
	QueryResult<Folder> getFolders(String locale, String actor, String uiChannel, Query query, String path, Map<String, Object> context) throws Exception;

	void trashFile(String locale, String email, String fileId, boolean trash) throws Exception;
}