package com.floreysoft.collaboration.shared.picker;

import java.io.Serializable;
import java.util.List;

public class Row implements Serializable {
	private static final long serialVersionUID = 1L;
	private String id;
	private List<String> values;
	
	public Row() {
	}

	public Row(String id, List<String> values) {
		this.id = id;
		this.values = values;
	}

	public List<String> getValues() {
		return values;
	}

	public void setValues(List<String> values) {
		this.values = values;
	}

	public String getId() {
		return id;
	}
}