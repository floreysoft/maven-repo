package com.floreysoft.collaboration.shared.command;

public class RenameCommand extends Command {
	private String name;
	private String description;
	
	public RenameCommand() {
	}
	
	public RenameCommand(String name, String description) {
		this.name = name;
		this.description = description;
	}

	public String getName() {
		return name;
	}

	public String getDescription() {
		return description;
	}

	@Override
	public int getMaxDelay() {
		return 2000;
	}

	@Override
	public boolean isUndoSupported() {
		return true;
	}
}
