package com.floreysoft.collaboration.shared;

import java.io.Serializable;
import java.util.Date;

public class ChatMessage implements Serializable {
	private String displayName, photoUrl, color, message;
	private Date timestamp;

	public ChatMessage() {
	}

	public ChatMessage(String displayName, String photoUrl, String color, String message, Date timestamp) {
		super();
		this.displayName = displayName;
		this.photoUrl = photoUrl;
		this.color = color;
		this.message = message;
		this.timestamp = timestamp;
	}

	public String getDisplayName() {
		return displayName;
	}

	public String getPhotoUrl() {
		return photoUrl;
	}

	public String getColor() {
		return color;
	}

	public String getMessage() {
		return message;
	}

	public Date getTimestamp() {
		return timestamp;
	}
}
