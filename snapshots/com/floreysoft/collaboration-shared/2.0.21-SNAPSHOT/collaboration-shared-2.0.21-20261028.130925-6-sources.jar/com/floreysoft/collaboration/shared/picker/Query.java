package com.floreysoft.collaboration.shared.picker;

import com.google.gwt.user.client.rpc.IsSerializable;

public class Query implements IsSerializable {
	private int start, length;
	private String cursor;
	private String term;
	private String folderId;

	public Query() {
	}

	public Query(int start, int length, String term, String folderId) {
		this.start = start;
		this.length = length;
		this.term = term;
		this.folderId = folderId;
	}

	public Query(int start, int length, String cursor, String term, String folderId) {
		this.start = start;
		this.cursor = cursor;
		this.length = length;
		this.term = term;
		this.folderId = folderId;
	}

	public String getCursor() {
		return cursor;
	}

	public int getStart() {
		return start;
	}

	public int getLength() {
		return length;
	}

	public String getTerm() {
		return term;
	}

	public String getFolderId() {
		return folderId;
	}
}