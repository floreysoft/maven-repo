package com.floreysoft.collaboration.shared.event;

import com.floreysoft.appcore.shared.event.TaskEvent;

public class FileTrashedEvent extends TaskEvent {
	private String fileId;
	private boolean forever;
	private boolean trashed;

	public FileTrashedEvent() {
	}

	public FileTrashedEvent(String fileId, boolean trashed, boolean forever) {
		this.fileId = fileId;
		this.trashed = trashed;
		this.forever = forever;
	}

	public String getFileId() {
		return fileId;
	}
	
	public boolean isTrashed() {
		return trashed;
	}

	public boolean isForever() {
		return forever;
	}
}