package com.floreysoft.collaboration.shared;

import java.util.List;

import com.google.gwt.user.client.rpc.IsSerializable;

public class QueryResult<T> implements IsSerializable {
	private List<T> items;
	private String cursor;
	private boolean moreEntries = true;

	public QueryResult() {
	}

	public QueryResult(List<T> items) {
		this.items = items;
		cursor = null;
	}

	public QueryResult(List<T> items, String cursor) {
		this.items = items;
		this.cursor = cursor;
	}

	public QueryResult(List<T> items, String cursor, boolean moreEntries) {
		this.items = items;
		this.cursor = cursor;
		this.moreEntries = moreEntries;
	}

	public List<T> getItems() {
		return items;
	}

	public String getCursor() {
		return cursor;
	}

	public boolean hasMoreEntries() {
		return moreEntries;
	}
}