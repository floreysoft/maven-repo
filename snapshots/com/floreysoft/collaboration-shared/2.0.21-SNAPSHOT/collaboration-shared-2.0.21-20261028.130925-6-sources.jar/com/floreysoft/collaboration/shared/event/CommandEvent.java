package com.floreysoft.collaboration.shared.event;

import com.floreysoft.appcore.shared.event.TaskEvent;

public class CommandEvent extends TaskEvent {
	private String uiChannel, fileId;
	private long revision;

	public CommandEvent() {
	}

	public CommandEvent(String uiChannel, String fileId) {
		this(uiChannel, fileId, 0L);
	}
			
	public CommandEvent(String uiChannel, String fileId, long revision) {
		this.uiChannel = uiChannel;
		this.fileId = fileId;
		this.revision = revision;
	}
	
	public String getFileId() {
		return fileId;
	}
	
	public long getRevision() {
		return revision;
	}

	public boolean isLocal(String uiChannel) {
		return uiChannel.equals(this.uiChannel);
	}
}

