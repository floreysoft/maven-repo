package com.floreysoft.collaboration.shared;

import java.io.Serializable;

public class DriveFileRevision implements Serializable {
	private String id, userDisplayName, userPhotoUrl;
	private long fileSize;
	private boolean pinned;
	private long modifiedDate;
	private String content;
	private String commentPositions;
	
	public DriveFileRevision() {
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getCommentPositions() {
		return commentPositions;
	}

	public void setCommentPositions(String commentPositions) {
		this.commentPositions = commentPositions;
	}

	public String getUserDisplayName() {
		return userDisplayName;
	}

	public void setUserDisplayName(String userDisplayName) {
		this.userDisplayName = userDisplayName;
	}

	public String getUserPhotoUrl() {
		return userPhotoUrl;
	}

	public void setUserPhotoUrl(String userPhotoUrl) {
		this.userPhotoUrl = userPhotoUrl;
	}

	public long getFileSize() {
		return fileSize;
	}

	public void setFileSize(long fileSize) {
		this.fileSize = fileSize;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isPinned() {
		return pinned;
	}

	public void setPinned(boolean pinned) {
		this.pinned = pinned;
	}

	public void setMofifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	public long getModifiedDate() {
		return modifiedDate;
	}

	public void setModifiedDate(long modifiedDate) {
		this.modifiedDate = modifiedDate;
	}
}
