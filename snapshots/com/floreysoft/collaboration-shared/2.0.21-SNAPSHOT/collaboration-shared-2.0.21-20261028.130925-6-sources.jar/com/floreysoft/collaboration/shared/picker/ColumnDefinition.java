package com.floreysoft.collaboration.shared.picker;

import com.google.gwt.user.client.rpc.IsSerializable;

public class ColumnDefinition implements IsSerializable {
	private String id, displayName;
	private Integer width;
	private Type type;
	private boolean visible, searchable;
	
	public enum Type {
		STRING, BOOLEAN, DATE, IMAGE, IMAGE_ICON
	}
	
	public ColumnDefinition() {
	}

	public ColumnDefinition(String id, String displayName, Integer width, Type type, boolean visible, boolean searchable) {
		this.id = id;
		this.displayName = displayName;
		this.width = width;
		this.type = type;
		this.visible = visible;
		this.searchable = searchable;
	}

	public String getId() {
		return id;
	}

	public String getDisplayName() {
		return displayName;
	}

	public Type getType() {
		return type;
	}

	public boolean isVisible() {
		return visible;
	}

	public boolean isSearchable() {
		return searchable;
	}

	public Integer getWidth() {
		return width;
	}
}