package com.floreysoft.appcore.shared;

import java.io.Serializable;
import java.util.Map;

public class LicenseState implements Serializable {
	private Map<String,Integer> state;
	private License license;
	
	public LicenseState() {
	}

	public LicenseState(Map<String, Integer> state, License license) {
		this.state = state;
		this.license = license;
	}

	public LicenseState(License license) {
		this.license = license;
	}

	public LicenseState(Map<String, Integer> state) {
		this.state = state;
	}

	public License getLicense() {
		return license;
	}

	public Map<String, Integer> getState() {
		return state;
	}
}