package com.floreysoft.appcore.shared.event;


public class ReconnectEvent extends TaskEvent {
	public ReconnectEvent() {
	}
}
