package com.floreysoft.appcore.shared;

public class TokenInvalidException extends Exception {
	private static final long serialVersionUID = 1L;

	public TokenInvalidException() {
		super("Security token invalid");
	}
}
