package com.floreysoft.appcore.shared;

import java.io.Serializable;
import java.util.Map;

public class License implements Serializable {
	private String market, licensee, service, owner;
	private long expires;
	private Map<String,String> properties;
	private boolean trial;

	public License() {}
	
	public License(String licensee, String service, String owner, long expires, Map<String, String> properties, boolean trial, String market) {
		this.licensee = licensee;
		this.service = service;
		this.owner = owner;
		this.expires = expires;
		this.properties = properties;
		this.trial = trial;
		this.market = market;
	}

	public String getOwner() {
		return owner;
	}

	public String getLicensee() {
		return licensee;
	}

	public String getService() {
		return service;
	}

	public long getExpires() {
		return expires;
	}

	public Map<String, String> getProperties() {
		return properties;
	}

	public String getProperty(String name) {
		return properties == null ? null : properties.get(name);
	}

	public boolean isTrial() {
		return trial;
	}

	public String getMarket() {
		return market;
	}
}
