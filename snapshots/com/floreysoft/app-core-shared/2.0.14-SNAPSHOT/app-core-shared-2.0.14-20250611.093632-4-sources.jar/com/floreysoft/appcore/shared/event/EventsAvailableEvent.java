package com.floreysoft.appcore.shared.event;

import java.util.List;

public class EventsAvailableEvent extends TaskEvent {
	private List<String> keys;
	private int size;

	public EventsAvailableEvent() {
	}

	public EventsAvailableEvent(List<String> keys, int size) {
		this.keys = keys;
		this.size = size;
	}

	public List<String> getKeys() {
		return keys;
	}

	public int getSize() {
		return size;
	}
}