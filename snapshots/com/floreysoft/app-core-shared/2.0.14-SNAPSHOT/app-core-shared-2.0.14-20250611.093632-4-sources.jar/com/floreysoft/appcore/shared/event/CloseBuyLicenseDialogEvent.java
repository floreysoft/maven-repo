package com.floreysoft.appcore.shared.event;

public class CloseBuyLicenseDialogEvent extends TaskEvent {
	public CloseBuyLicenseDialogEvent() {
	}
}