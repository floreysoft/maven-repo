package com.floreysoft.appcore.shared.event;

import java.io.Serializable;

public class TaskEvent implements Serializable {
	private static final long serialVersionUID = 1L;

	public TaskEvent() {
	}
}
