package com.floreysoft.appcore.shared;

public class AccessDeniedException extends Exception {
	private String id, email, displayName;
	private Scope[] scopes;

	public AccessDeniedException() {
	}

	public AccessDeniedException(String id, String email, String displayName, Scope []scopes, String message) {
		super(message);
		this.id = id;
		this.email = email;
		this.displayName = displayName;
		this.scopes = scopes;
	}

	public String getId() {
		return id;
	}

	public String getEmail() {
		return email;
	}

	public String getDisplayName() {
		return displayName;
	}

	public Scope []getScopes() {
		return scopes;
	}
}