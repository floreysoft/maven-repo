package com.floreysoft.appcore.shared;

import java.io.Serializable;

public class Scope implements Serializable {
	private Scope parent;
	private String scope, projectId;

	public Scope() {
	}
	
	public Scope(String scope) {
		this.scope = scope;
	}
	
	public Scope(String scope, String projectId) {
		this.scope = scope;
		this.projectId = projectId;
	}
	
	public Scope(Scope parent, String scope) {
		this.parent = parent;
		this.scope = scope;
	}
	
	public Scope(Scope parent, String scope, String projectId) {
		this.parent = parent;
		this.scope = scope;
		this.projectId = projectId;
	}

	public Scope getParent() {
		return parent;
	}

	public String getScope() {
		return scope;
	}

	public String getProjectId() {
		return projectId;
	}

	@Override
	public boolean equals(Object obj) {
		return ((Scope)obj).getScope().equals(scope) && ( projectId == null && ((Scope)obj).projectId == null || projectId != null && projectId.equals(((Scope)obj).projectId));
	}
	
	@Override
	public String toString() {
		return scope;
	}
	
	@Override
	public int hashCode() {
		return scope.hashCode();
	}
}
