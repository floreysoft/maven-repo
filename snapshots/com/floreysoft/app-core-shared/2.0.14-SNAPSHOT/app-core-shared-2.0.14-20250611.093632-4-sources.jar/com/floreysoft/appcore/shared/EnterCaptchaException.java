package com.floreysoft.appcore.shared;

public class EnterCaptchaException extends Exception {
	private static final long serialVersionUID = 1L;

	private String email;
	private String captchaToken;
	private String captchaUrl;

	public EnterCaptchaException() {
		super("Captcha required to authenticate user");
	}
	
	public EnterCaptchaException(String email, String captchaToken, String captchaUrl) {
		super("Captcha required to authenticate user");
		this.email = email;
		this.captchaToken = captchaToken;
		this.captchaUrl = captchaUrl;
	}

	public String getCaptchaToken() {
		return captchaToken;
	}

	public String getCaptchaUrl() {
		return captchaUrl;
	}

	public String getEmail() {
		return email;
	}
}