package com.floreysoft.appcore.shared;

public class ForceClientRedirectException extends Exception {
	private String title, message, url, target;

	public ForceClientRedirectException() {
	}

	public ForceClientRedirectException(String title, String message, String url) {
		this(title, message, url, null);
	}

	public ForceClientRedirectException(String title, String message, String url, String target) {
		super(message);
		this.title = title;
		this.message = message;
		this.url = url;
		this.target = target;
	}

	public String getMessage() {
		return message;
	}

	public String getUrl() {
		return url;
	}

	public String getTitle() {
		return title;
	}

	public String getTarget() {
		return target;
	}
}
