package com.floreysoft.appcore.shared.event;

public class TabEvent extends TaskEvent {
	protected String actor, email, domain, type, id;

	public TabEvent() {
	}

	public TabEvent(String actor, String owner, String email, String domain, String type) {
		this.actor = actor;
		this.email = email;
		this.domain = domain;
		this.type = type;
		this.id = owner+":"+type;
	}

	public String getActor() {
		return actor;
	}

	public String getEmail() {
		return email;
	}

	public String getDomain() {
		return domain;
	}

	public String getType() {
		return type;
	}

	public String getId() {
		return id;
	}
}