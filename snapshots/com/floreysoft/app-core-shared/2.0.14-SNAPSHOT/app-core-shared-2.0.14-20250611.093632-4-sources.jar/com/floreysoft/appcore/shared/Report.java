package com.floreysoft.appcore.shared;

import java.util.ArrayList;
import java.util.List;

import com.floreysoft.appcore.shared.Report.Message.State;
import com.google.gwt.user.client.rpc.IsSerializable;

public class Report implements IsSerializable {
                                           //Full class name to workround on Maven compiler bug
	public static class Message implements com.google.gwt.user.client.rpc.IsSerializable {
		public enum State implements IsSerializable {
			SUCCESS, ERROR;
		}

		private State state = State.SUCCESS;
		private String text;

		public Message() {
		}

		private Message(String text, State state) {
			this.text = text;
			this.state = state;
		}

		public State getState() {
			return state;
		}

		public String getText() {
			return text;
		}
	}

	private List<Message> messages;

	public Report() {
	}

	public void addMessage(String message) {
		if (messages == null) {
			messages = new ArrayList<Message>();
		}
		messages.add(new Message(message, State.SUCCESS));
	}

	public List<Message> getMessages() {
		return messages;
	}

	public void addError(String message) {
		if (messages == null) {
			messages = new ArrayList<Message>();
		}
		messages.add(new Message(message, State.ERROR));
	}
}
