package com.floreysoft.appcore.shared;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Random;

public class SharedUtils {
	private final static String chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	private final static int ID_DEFAULT_LENGTH = 20;
	private final static Random rand = new Random(System.currentTimeMillis());

	public static String generateId() {
		return generateId(ID_DEFAULT_LENGTH, true);
	}
	
	public static String generateId(int length) {
		return generateId(length, false);
	}
		
	public static String generateId(int length, boolean appendTimestamp) {
		StringBuffer id = new StringBuffer();
		for (int i = 0; i < ID_DEFAULT_LENGTH; i++) {
			id.append(chars.charAt(rand.nextInt(chars.length())));
		}
		id.append(String.valueOf(System.currentTimeMillis()).substring(5));
		return id.toString();
	}
	
	public static String toCSV(Collection<String> values) {
		return toCSV(values, ',');
	}

	public static String toCSV(Collection<String> values, char delimiter) {
		StringBuilder sb = new StringBuilder();
		if (values != null) {
			boolean first = true;
			for (String value : values) {
				if (!first) {
					sb.append(delimiter);
				}
				first = false;
				if ( value != null ) {
					sb.append(value.replace("" + delimiter, "\\" + delimiter));
				}
			}
		}
		return sb.toString();
	}

	public static List<String> fromCSV(String csv, char delimiter) {
		List<String> values = new ArrayList<String>();
		if (csv == null || csv.isEmpty() ) {
			return values;
		}
		int mode = 0;
		StringBuffer value = new StringBuffer();
		for (int i = 0; i < csv.length(); i++) {
			char currentChar = csv.charAt(i);
			char lastChar = (i == 0 ? 0 : csv.charAt(i - 1));
			char nextChar = (i == csv.length() - 1 ? 0 : csv.charAt(i + 1));
			if (mode == 0) {
				if (currentChar == delimiter && lastChar != '\\') {
					values.add(value.toString().replace("\\"+delimiter, ""+delimiter));
					value = new StringBuffer();
				} else if ((lastChar == 0 || lastChar == delimiter) && (currentChar == '\'' || currentChar == '"')) {
					mode = currentChar;
				} else {
					value.append(currentChar);
				}
			} else {
				if (currentChar == mode && nextChar == delimiter) {
					mode = 0;
				} else {
					value.append(currentChar);
				}
			}
		}
		values.add(value.toString().replace("\\"+delimiter, ""+delimiter));
		return values;
	}

	public static String toSCSV(List<List<String>> rows) {
		return toTable(rows, ',', ';');
	}
	
	public static String toTable(List<List<String>> rows, char columnDelimiter, char rowDelimiter) {
		StringBuilder sb = new StringBuilder();
		if (rows != null) {
			boolean firstRow = true;
			for (Collection<String> columns : rows) {
				if (!firstRow) {
					sb.append(rowDelimiter);
				}
				firstRow = false;
				if (columns != null) {
					boolean firstColumn = true;
					for (String column : columns) {
						if (!firstColumn) {
							sb.append(columnDelimiter);
						}
						firstColumn = false;
						column = column.replace("" + columnDelimiter, "\\" + columnDelimiter);
						column = column.replace("" + rowDelimiter, "\\" + rowDelimiter);
						sb.append(column);
					}
				}
			}
		}
		return sb.toString();
	}

	public static List<List<String>> fromSCSV(String csv) {
		return fromTable(csv, ',', ';');
	}
		
	public static List<List<String>> fromTable(String csv,  char columnDelimiter, char rowDelimiter) {
		List<List<String>> rows = new ArrayList<List<String>>();
		List<String> columns = new ArrayList<String>();
		if (csv == null || csv.isEmpty()) {
			return rows;
		}
		int mode = 0;
		boolean endsWithRowDelimiter = false;
		StringBuffer column = new StringBuffer();
		for (int i = 0; i < csv.length(); i++) {
			endsWithRowDelimiter = false;
			char currentChar = csv.charAt(i);
			char lastChar = (i == 0 ? 0 : csv.charAt(i - 1));
			char nextChar = (i == csv.length() - 1 ? 0 : csv.charAt(i + 1));
			if (mode == 0) {
				if (currentChar == columnDelimiter && lastChar != '\\') {
					columns.add(replaceDelimiters(column, columnDelimiter, rowDelimiter));
					column = new StringBuffer();
				} else if (currentChar == rowDelimiter && lastChar != '\\') {
					endsWithRowDelimiter = true;
					columns.add(replaceDelimiters(column, columnDelimiter, rowDelimiter));
					column = new StringBuffer();
					rows.add(columns);
					columns = new ArrayList<String>();
				} else if ((lastChar == 0 || lastChar == columnDelimiter) && (currentChar == '\'' || currentChar == '"')) {
					mode = currentChar;
				} else {
					column.append(currentChar);
				}
			} else {
				if (currentChar == mode && nextChar == columnDelimiter) {
					mode = 0;
				} else {
					column.append(currentChar);
				}
			}
		}
		if (!endsWithRowDelimiter) {
			columns.add(replaceDelimiters(column, columnDelimiter, rowDelimiter));
		}
		if ( columns.size() > 0 ) {
			rows.add(columns);
		}
		return rows;
	}

	public static List<String> fromCSV(String csv) {
		return fromCSV(csv, ',');
	}

	private static String replaceDelimiters(StringBuffer buffer, char columnDelimiter, char rowDelimiter) {
		return buffer.toString().replace("\\"+columnDelimiter, ""+columnDelimiter).replace("\\"+rowDelimiter, ""+rowDelimiter);
	}

	public static String toCamelCase(String s, String delimiter, String separator) {
		return toCamelCase(s, delimiter, separator, false, true);
	}

	public static String toCamelCase(String s, String delimiter, String separator, boolean firstLetterUppercase) {
		return toCamelCase(s, delimiter, separator, firstLetterUppercase, false);
	}

	public static String toCamelCase(String s, String delimiter, String separator, boolean firstLetterUppercase, boolean keepUppercaseLetters) {
		String[] parts = s.split(delimiter);
		boolean first = true;
		StringBuilder camelCaseString = new StringBuilder();
		for (String part : parts) {
			if (part != null && !part.isEmpty()) {
				if (!first) {
					camelCaseString.append(separator);
				}
				String segment = part;
				if ( !keepUppercaseLetters ) {
					segment = segment.toLowerCase();
				}
				if (firstLetterUppercase || !first) {
					segment = segment.substring(0, 1).toUpperCase() + segment.substring(1);
				}
				camelCaseString.append(segment);
				first = false;
			}
		}
		return camelCaseString.toString();
	}
}