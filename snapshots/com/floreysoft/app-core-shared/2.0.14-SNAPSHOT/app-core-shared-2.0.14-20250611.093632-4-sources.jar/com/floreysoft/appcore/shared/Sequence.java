package com.floreysoft.appcore.shared;

import com.google.gwt.user.client.rpc.IsSerializable;

public class Sequence implements IsSerializable {
	private String key;
	private String name;
	private long value;
	
	public Sequence() {
	}

	public Sequence(String key, String name, long value) {
		this.key = key;
		this.name = name;
		this.value = value;
	}

	public String getKey() {
		return key;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getValue() {
		return value;
	}

	public void setValue(long value) {
		this.value = value;
	}
}