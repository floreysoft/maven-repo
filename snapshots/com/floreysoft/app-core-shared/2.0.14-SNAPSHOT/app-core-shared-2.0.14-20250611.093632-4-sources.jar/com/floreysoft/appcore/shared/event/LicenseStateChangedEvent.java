package com.floreysoft.appcore.shared.event;

import com.floreysoft.appcore.shared.LicenseState;

public class LicenseStateChangedEvent extends TaskEvent {
	private LicenseState licenseState;

	public LicenseStateChangedEvent() {
	}

	public LicenseStateChangedEvent(LicenseState licenseState) {
		this.licenseState = licenseState;
	}

	public LicenseState getLicenseState() {
		return licenseState;
	}
}