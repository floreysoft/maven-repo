package com.floreysoft.appcore.shared;

public interface SharedConstants {
    public final static String PARAMETER_SKIP_SPLASHSCREEN = "skip";

    public final static String STRIPE_FLOREYSOFT_PUBLIC = "pk_live_KfJ48tEJr7R0Ca44yqVBONCs";
	public static final String REFERRAL_KEY = "ctw13dre$18";

    public final static Scope GMAIL_SCOPE = new Scope("https://mail.google.com/");
	public final static Scope GMAIL_COMPOSE_SCOPE = new Scope(GMAIL_SCOPE, "https://www.googleapis.com/auth/gmail.compose");
	public final static Scope GMAIL_SEND_SCOPE = new Scope(GMAIL_COMPOSE_SCOPE, "https://www.googleapis.com/auth/gmail.send");
	public final static Scope GMAIL_SETTINGS_BASIC_SCOPE = new Scope("https://www.googleapis.com/auth/gmail.settings.basic");
	public final static Scope GMAIL_SETTINGS_SHARING_SCOPE = new Scope("https://www.googleapis.com/auth/gmail.settings.sharing");
	public final static Scope GMAIL_METADATA_SCOPE = new Scope(GMAIL_SCOPE, "https://www.googleapis.com/auth/gmail.metadata");

	public final static Scope USERINFO_EMAIL_SCOPE = new Scope("https://www.googleapis.com/auth/userinfo.email");
	public final static Scope USERINFO_PROFILE_SCOPE = new Scope("https://www.googleapis.com/auth/userinfo.profile");

	public static final String UI_CHANNEL = "ui";

	public final static Scope GOOGLE_DIRECTORY_READ_USERS_SCOPE = new Scope("https://www.googleapis.com/auth/admin.directory.user.readonly");

	public static final String NOTE_STYLE = "note";
	public static final String MESSAGE_STYLE = "message";
	public static final String ERROR_STYLE = "error";

	public static final String FIREBASE_PROJECT_ID = "firebaseProjectId";
	public static final String FIREBASE_API_KEY = "firebaseApiKey";
	public static final String FIREBASE_APP_ID = "firebaseAppId";
	public static final String FIREBASE_MESSAGING_SENDER_ID = "firebaseMessagingSenderId";
	public static final String FIREBASE_SERVICE_ACCOUNT = "firebaseServiceAccount";
	public static final String FIREBASE_TOKEN = "ft";

	public static final String TITLE = "title";
	public static final String APPLICATION = "application";
	public static final String ENTRY_POINT = "entryPoint";
	public static final String HELP_URL = "helpUrl";
	public static final String LOGO_URL = "logoUrl";
	public static final String TOS_ACCEPTED = "tos";
	public static final String NEWS_TIMESTAMP = "newsTimestamp";
	public static final String NEWS_URL = "newsUrl";
	public static final String ACCOUNT_KEY_CONFIG = "accountKeyConfig";
	public static final String VERSION = "version";
	public static final String UPDATE_AVAILABLE = "updateAvailable";
	public static final String MARKET_URL = "marketUrl";
	public final static String APPLICATION_IDENTIFIER = "applicationId";
	public static final String EXPIRES = "expires";
	public static final String ACCOUNT = "account";
	public final static String PRESELECTED_DOMAIN = "predomain";
	public static final String DEPLOYMENT = "deployment";
	public static final String DEDICATED_DEPLOYMENT = "dedicated";
	public static final String PUBLIC_DEPLOYMENT = "public";
	public static final String CUSTOM_DEPLOYMENT = "custom";
    public final static String CLIENT_ID = "clientId";
    public final static String CLIENT_SECRET = "clientSecret";
    public final static String REDIRECT_URI = "redirectUri";
	public static final String STRIPE_CUSTOMER_ID = "scus";
	public static final String STRIPE_CURRENCY = "scur";
	public static final String REFERRAL = "referral";

	public static final String PARAMETER_LOCALE = "locale";

	public static final String ERROR_INVALID_DOMAIN = "invDom";

	public static final String LOGOUT_FROM_GOOGLE = "logout";
	public static final String EMAIL = "email";
	public static final String DOMAIN = "domain";
	public static final String PHOTO = "photo";
	public static final String DISPLAY_NAME = "displayName";
	public static final String IS_ADMIN = "admin";
	public static final String IS_EMBEDDED = "embed";
	public static final String LICENSEE = "licensee";
	public static final String EDITION = "edition";
	public static final String TRIAL = "trial";
	public static final String FREE = "free";
	public static final String LOGOUT_URL = "logoutUrl";
	public static final String MESSAGE = "message";
	public static final String MAX_ACCOUNTS_EXCEEDED = "mae";
	public static final String LICENSE = "license";
	public static final String LICENSE_OK = "ok";
	public static final String LICENSE_NOT_ACTIVE = "no";
	public static final String LICENSE_ERROR = "error";
	public static final String LICENSE_DISABLED = "disabled";

	public String[] DEFAULT_COLORS = new String[] { "rgb(242,32,0)", "rgb(0,2,124)", "rgb(232,181,0)", "rgb(142,69,0)", "rgb(247,148,0)", "rgb(0,0,255)", "rgb(60,72,12)",
			"rgb(0,225,60)", "rgb(150,2,16)", "rgb(60,12,122)", "rgb(42,97,0)", "rgb(50,72,40)", "rgb(100,100,10)", "rgb(255,0,0)", "rgb(0,200,0)" };

}