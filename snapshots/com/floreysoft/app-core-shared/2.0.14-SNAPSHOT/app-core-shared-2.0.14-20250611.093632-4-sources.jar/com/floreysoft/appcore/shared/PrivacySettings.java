package com.floreysoft.appcore.shared;

import com.google.gwt.user.client.rpc.IsSerializable;

public class PrivacySettings implements IsSerializable {
	private boolean productNews, companyNews, supportNews;	
	private String logLevel;
	private String accountKey;
	
	public PrivacySettings() {
	}

	public PrivacySettings(boolean productNews, boolean companyNews, boolean supportNews, String logLevel, String accountKey) {
		this.productNews = productNews;
		this.companyNews = companyNews;
		this.supportNews = supportNews;
		this.logLevel = logLevel;
		this.accountKey = accountKey;
	}

	public boolean isProductNews() {
		return productNews;
	}

	public boolean isCompanyNews() {
		return companyNews;
	}

	public boolean isSupportNews() {
		return supportNews;
	}

	public String getLogLevel() {
		return logLevel;
	}

	public String getAccountKey() {
		return accountKey;
	}
}