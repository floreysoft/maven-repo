package com.floreysoft.appcore.shared;

import java.util.List;
import java.util.Map;

import com.floreysoft.appcore.shared.event.TaskEvent;
import com.google.gwt.user.client.rpc.AsyncCallback;

public interface AppCoreServiceAsync {
	void setSettings(String locale, String email, Map<String, String> settings, AsyncCallback<Void> callback);

	void getSettings(String locale, String email, AsyncCallback<Map<String, String>> callback);

	void acceptTOS(String locale, String email, boolean productNews, boolean supportNews, boolean companyNews, AsyncCallback<Void> callback);

	void newsRead(String locale, String email, AsyncCallback<Void> callback); 

	void getAvailableEvents(List<String> keys, int length, AsyncCallback<List<TaskEvent>> callback);

	void getHiddenHints(String locale, String email, AsyncCallback<List<String>> callback);

	void hideHint(String locale, String email, String id, AsyncCallback<Void> callback);

	void getLicenseState(String locale, String email, AsyncCallback<LicenseState> callback);

	void getAccessToken(String locale, String email, Scope scope, AsyncCallback<AccessToken> callback);

	void getPrivacySettings(String locale, String email, AsyncCallback<PrivacySettings> callback);

	void setPrivacySettings(String locale, String email, PrivacySettings settings, AsyncCallback<Void> callback);

	void deleteAccount(String locale, String actor, AsyncCallback<Void> serverCallback);

	void requestData(String locale, String actor, AsyncCallback<Void> serverCallback);
	
	void generateAccountKey(String locale, String actor, String accountKeyConfig, AsyncCallback<String> serverCallback);
}