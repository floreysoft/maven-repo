package com.floreysoft.appcore.shared;

import com.google.gwt.user.client.rpc.IsSerializable;

public class AccessToken implements IsSerializable {
	private String token;
	private int expires;
	
	public AccessToken() {
	}

	public AccessToken(String token, int expires) {
		this.token = token;
		this.expires = expires;
	}

	public String getToken() {
		return token;
	}

	public int getExpires() {
		return expires;
	}
}