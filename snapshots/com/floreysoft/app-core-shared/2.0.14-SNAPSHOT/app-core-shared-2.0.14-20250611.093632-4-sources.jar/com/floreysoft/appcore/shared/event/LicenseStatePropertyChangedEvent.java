package com.floreysoft.appcore.shared.event;

public class LicenseStatePropertyChangedEvent extends TaskEvent {
	private String property;
	private int value;

	public LicenseStatePropertyChangedEvent() {
	}

	public LicenseStatePropertyChangedEvent(String property, int value) {
		this.property = property;
		this.value = value;
	}

	public String getProperty() {
		return property;
	}

	public int getValue() {
		return value;
	}
}