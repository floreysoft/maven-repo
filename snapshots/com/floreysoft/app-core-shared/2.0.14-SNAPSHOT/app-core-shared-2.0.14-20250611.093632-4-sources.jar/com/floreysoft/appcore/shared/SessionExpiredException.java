package com.floreysoft.appcore.shared;

public class SessionExpiredException extends Exception {
	public SessionExpiredException(String message) {
		super(message);
	}
}
