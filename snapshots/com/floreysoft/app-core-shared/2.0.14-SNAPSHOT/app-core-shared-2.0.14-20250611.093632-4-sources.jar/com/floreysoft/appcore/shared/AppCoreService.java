package com.floreysoft.appcore.shared;

import java.util.List;
import java.util.Map;

import com.floreysoft.appcore.shared.event.TaskEvent;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

/**
 * @author Daniel Florey
 * 
 */
@RemoteServiceRelativePath("appCoreService")
public interface AppCoreService extends RemoteService {
	AccessToken getAccessToken(String locale, String email, Scope scope) throws Exception;

	Map<String, String> getSettings(String locale, String email) throws Exception; 

	void setSettings(String locale, String email, Map<String,String> settings) throws Exception;

	void acceptTOS(String locale, String email, boolean productNews, boolean supportNews, boolean companyNews) throws Exception;

	void newsRead(String locale, String email) throws Exception;
	
	List<TaskEvent> getAvailableEvents(List<String> keys, int length) throws Exception;

	List<String> getHiddenHints(String locale, String email) throws Exception;

	void hideHint(String locale, String email, String id) throws Exception;
	
	LicenseState getLicenseState(String locale, String email) throws Exception;
	
	PrivacySettings getPrivacySettings(String locale, String email) throws Exception;
	
	void setPrivacySettings(String locale, String email, PrivacySettings settings) throws Exception;

	void deleteAccount(String locale, String actor) throws Exception;

	void requestData(String locale, String actor) throws Exception;
	
	String generateAccountKey (String locale, String actor, String accountKeyConfig) throws Exception;
} 
